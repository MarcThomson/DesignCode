alphaComponents = [...
K/(K+1)	;	%	ALA
K/(K+1)	;	%	ANTI
K/(K+1)	;	%	ASN
K/(K+1)	;	%	ASP
0.99		;	%	BIOM
K/(K+1)	;	%	C_C
K/(K+1)	;	%	CO2
K/(K+1)	;	%	GLC
K/(K+1)	;	%	GLN
K/(K+1)	;	%	GLU
K/(K+1)	;	%	GLY
K/(K+1)	;	%	LAC
K/(K+1)	;	%	NH3
K/(K+1)	;	%	O2
K/(K+1)	;	%	SER
];