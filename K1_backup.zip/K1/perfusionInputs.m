%
C_i_in = [
0.9	;	%	ALA
0	;	%	ANTI
21	;	%	ASN
2	;	%	ASP
0	;	%	BIOM
1.5	;	%	C_C
0	;	%	CO2
100	;	%	GLC
3.9 ;	%	GLN
0.6	;	%	GLU
3.4	;	%	GLY
1	;	%	LAC
1	;	%	NH3
100	;	%	O2
11	;	%	SER
]; %mM