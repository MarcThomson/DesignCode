function p = test2Fxn(x)
p = x.^2;
end