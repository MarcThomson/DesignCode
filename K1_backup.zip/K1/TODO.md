Tasks (Updated 2/2/2018):

Before 2/3/2018:
- Type out rate laws
- Type out kinetic constants
- Find/Type initial conditions
On/After 2/3/2018:
- Create a stoich matrix
- Write a solving algorithm
