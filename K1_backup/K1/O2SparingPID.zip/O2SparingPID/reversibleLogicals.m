%Reversible = 1, irreversible = 0

reversible = [...
0
1
1
0
0
0
0
1
1
0
0
0
0
0
0
0
0
0
0
0
1
1
0
1
0
1
1
0
1
0
0
0
1
0
];

%checked by Eddie/Marc 2/3
