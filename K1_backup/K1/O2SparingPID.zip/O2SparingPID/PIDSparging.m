figure(1);clf;clear;
clear
load('Gas_Output.mat');
C_O2_vec = C_O2_vec - C_O2_vec(1) + 0.4189*1.2; 

K = [3 73 0.013 ; %O2
     0    0    0; %CO2   
     0   0   0];%Flow
%   K1  K2   K3
h = 10/24/60/15;
loopTime = 10/24/60;

Dt = 0.95; %m
A=Dt^2/4*pi;
shift = 0;
%

Qtotal=zeros(length(t),1);
QO2=zeros(length(t),1);
QCO2=zeros(length(t),1);


Nrad(1) = 1*2*pi;
Qtotal(1)=10e-3*A;
QCO2(1)=6E-2*Qtotal(1);
QO2(1)=0.4*Qtotal(1);



t_new = t(1):h:t(end);
C_O2_rxn = interp1(t,C_O2_vec,t_new);
C_CO2_rxn = interp1(t,C_CO2_vec,t_new);

C_O2_sparge = 0 * C_O2_rxn;
C_CO2_sparge = 0 * C_CO2_rxn;

CO2prop_vec = 0 * C_O2_rxn;
O2prop_vec = 0 * C_CO2_rxn;

for i = 2 : length(t_new)
    
    if t_new(i)>shiftDay
        shift = 1;
    end
    
   yO2 = QO2(i-1)/Qtotal(i-1);
   yCO2 = QCO2(i-1)/Qtotal(i-1);
    
   CO2Frac = (yCO2-400E-6)/(1-400E-6);
   airFrac = (1-yO2-CO2Frac)/(1-0.2095);
        
    [FO2_1, FCO2_1, ~, O2prop_vec(i-1), CO2prop_vec(i-1), ~] = ...
    spargerV2( C_O2_sparge(i-1) + C_O2_rxn(i-1),  C_CO2_sparge(i-1) + C_CO2_rxn(i-1),...
                    airFrac,CO2Frac,Qtotal(i-1),Dt,Nrad(i-1),t_new(i-1),shift);
    FO2_1 = 24*3600*FO2_1;
    FCO2_1 = 24*3600*FCO2_1;
    
   [FO2_2, FCO2_2, ~, ~, ~, ~] = ...
    spargerV2( C_O2_sparge(i-1) + C_O2_rxn(i-1)*0.5+C_O2_rxn(i)*0.5 + FO2_1*h/2,...
             C_CO2_sparge(i-1) + C_CO2_rxn(i-1)*0.5 + C_CO2_rxn(i)*0.5   + FCO2_1*h/2,...
                    airFrac,CO2Frac,Qtotal(i-1),Dt,Nrad(i-1),t_new(i-1)+h/2,shift);
    FO2_2 = 24*3600*FO2_2;
    FCO2_2 = 24*3600*FCO2_2;

    [FO2_3, FCO2_3, ~, ~, ~, ~] = ...
    spargerV2( C_O2_sparge(i-1) + C_O2_rxn(i-1)*0.5+C_O2_rxn(i)*0.5 + FO2_2*h/2,...
             C_CO2_sparge(i-1) + C_CO2_rxn(i-1)*0.5 + C_CO2_rxn(i)*0.5   + FCO2_2*h/2,...
                    airFrac,CO2Frac,Qtotal(i-1),Dt,Nrad(i-1),t_new(i-1)+h/2,shift);
    FO2_3 = 24*3600*FO2_3;
    FCO2_3 = 24*3600*FCO2_3;
    
    [FO2_4, FCO2_4, ~, ~, ~, ~] = ...
    spargerV2( C_O2_sparge(i-1) + C_O2_rxn(i) + FO2_3*h,  C_CO2_sparge(i-1) + C_CO2_rxn(i)  + FCO2_3*h,...
                    airFrac,CO2Frac,Qtotal(i-1),Dt,Nrad(i-1),t_new(i-1)+h,shift);
    FO2_4 = 24*3600*FO2_4;
    FCO2_4 = 24*3600*FCO2_4;    
    
    FO2 = (FO2_1 + 2*FO2_2 + 2*FO2_3 + FO2_3)/6;
    FCO2 = (FCO2_1 + 2*FCO2_2 + 2*FCO2_3 + FCO2_3)/6;            
    
%     if t_new(i+2) == 3
%         2+2
%     end
    %update for ith iteration
    C_O2_sparge(i) = C_O2_sparge(i-1) + h * FO2;
    C_CO2_sparge(i) = C_O2_sparge(i-1) + h * FCO2;
    
    %g
    [~, ~, Nrad(i), O2prop, CO2prop, dB(i)] = ...
    spargerV2(C_O2_sparge(i) + C_O2_rxn(i),  C_CO2_sparge(i) + C_CO2_rxn(i)  + FCO2_3*h,...
                    airFrac,CO2Frac,Qtotal(i-1),Dt,Nrad(i-1),t_new(i),shift);
    
    CO2prop_vec(i) = CO2prop;
    O2prop_vec(i) = O2prop;
                
    maxDer = 0;

    errorO2 = 0.5 - O2prop_vec(1:i);
    if i > 2
        
        %rxnDer = (-3*C_O2_rxn(i) - C_O2_rxn(i-2) + 4*C_O2_rxn(i-1))/(2*h);
        %QO2_SS = bisectO2(QCO2(i-1),Qtotal(i-1),C_O2_sparge(i)+C_O2_rxn(i),C_CO2_sparge(i)+C_CO2_rxn(i),Dt,Nrad(i),t_new(i),shift,rxnDer);
        
        der = (-3*errorO2(i) - errorO2(i-2) + 4*errorO2(i-1))/(2*h);
        if abs(der)>maxDer
            maxDer = der;
        end
        uO2 = K(1,1)*errorO2(i) + K(1,2) * trapz(t_new(1:i), errorO2(1:i)) + K(1,3) * der(end);
    else
       uO2 = 0; 
       %QO2_SS = QO2(i-1);
    end
    
    if mod(t_new(i),loopTime) == 0
        QO2(i) = QO2(1)*(1 + uO2);% QO2_SS +  ;   
        QCO2(i) = QCO2(i-1);%*(1 + uO2);
        Qtotal(i) = Qtotal(i-1);

        if QO2(i)>Qtotal(i)*(1-CO2Frac)
            Qtotal(i) = QO2(i)/(1-CO2Frac);
            if Qtotal(i)/A>18.1e-3
                Qtotal(i) = A*18.1e-3;
            end
            QO2(i) = Qtotal(i)*(1-CO2Frac);
        end
        if QO2(i) < 0
            QO2(i) = 0;
        end
    else
        QO2(i) = QO2(i-1);
        QCO2(i) = QCO2(i-1);
        Qtotal(i) = Qtotal(i-1);
    end
end

plot(t_new(1:i-1),O2prop_vec(1:i-1))
%axis([0,10,-0.2,2])