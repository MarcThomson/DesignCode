%guess
load('paramOutput_v1')
lb = x0/3;
ub = x0*3;

options = optimoptions('patternsearch','Display','iter','PlotFcn',@psplotbestf,'UseCompletePoll',true,'UseParallel',true,'Cache','on','MaxIterations',100);

parpool(2)
%lb = zeros(47,1);
%ub = 10000*ones(47,1);
fun = @batchFunction;
tic
[x,fval,exitflag,output]  = patternsearch(fun,x0,[],[],[],[],lb,ub,[],options)
toc